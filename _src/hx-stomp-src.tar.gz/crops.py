import subprocess,os,json
from PIL import Image,ImageChops,ImageDraw
D='/mnt/user-data/attachments/5700af35-afcf-5717-b93a-31c5326329cc/'
P={'s':D+'6bf277f3-HX_Stomp_3.0_Owners_Manual_-_Rev_D_-_Japanese_.pdf','e':D+'3221c8d4-HX_Edit_3.a_15_Pilots_Guide_-_Japanese_.pdf'}
C=json.load(open('crops.json'))
os.makedirs('img',exist_ok=True);os.makedirs('hi',exist_ok=True)
out=[]
for name,(t,pg,x0,y0,x1,y1) in C.items():
    src=f'hi/{t}{pg}.png'
    if not os.path.exists(src): subprocess.run(['pdftoppm','-f',str(pg),'-l',str(pg),'-r','220','-png','-singlefile',P[t],f'hi/{t}{pg}'],stderr=subprocess.DEVNULL)
    im=Image.open(src).convert('RGB');W,H=im.size
    c=im.crop((int(x0*W),int(y0*H),int(x1*W),int(y1*H)))
    bb=ImageChops.difference(c,Image.new('RGB',c.size,'white')).point(lambda v:255 if v>12 else 0).getbbox()
    if bb: c=c.crop((max(0,bb[0]-10),max(0,bb[1]-10),min(c.width,bb[2]+10),min(c.height,bb[3]+10)))
    if c.width>1400: c=c.resize((1400,int(c.height*1400/c.width)),Image.LANCZOS)
    c.save(f'img/{name}.webp',quality=86,method=6);out.append((name,c))
print(sum(os.path.getsize('img/'+f) for f in os.listdir('img'))//1024,'KB',len(out))
json.dump({n:list(c.size) for n,c in out},open('sizes.json','w'))
# montage
cols=5;tw,th=400,300
per=20
for p in range(0,len(out),per):
    sub=out[p:p+per];S=Image.new('RGB',(cols*tw,th*((len(sub)+cols-1)//cols)),(200,200,200));d=ImageDraw.Draw(S)
    for i,(n,c) in enumerate(sub):
        t=c.copy();t.thumbnail((tw-8,th-22));x,y=(i%cols)*tw+4,(i//cols)*th+18;S.paste(t,(x,y));d.text((x,y-14),n,fill='black')
    S.save(f'mont{p//per}.png')
