import re,base64,os
h=open('hx-guide.html',encoding='utf8').read()
T='OUT HX-STOMP まるわかり辞典'
h=h.replace('<title>HX Stomp まとめガイド</title>',f'<title>{T}</title>')
old='<p class="brand">HX Stomp / HX Edit まとめガイド ・ ファームウェア3.80、HX Edit 3.82 基準</p>'
if old in h:
    h=h.replace(old,'<header class="mast"><p class="mast-t">OUT HX-STOMP<span>まるわかり辞典</span></p><p class="brand">ファームウェア3.80、HX Edit 3.82 基準</p></header>')
    h=h.replace('/* fixed bottom bar */','.mast { margin-bottom: 20px; }\n.mast-t { font: 600 22px/1.25 var(--sans); margin: 0 0 4px; letter-spacing: .01em; }\n.mast-t span { display: block; font-size: 15px; font-weight: 600; color: var(--muted); margin-top: 2px; }\n.mast .brand { margin: 0; }\n\n/* fixed bottom bar */',1)
open('hx-guide.html','w',encoding='utf8').write(h)
s=h
s=re.sub(r'<link rel="stylesheet" href="https://fonts\.googleapis[^>]*>\n?','',s)
s=re.sub(r'<meta name="claude:viewport-fit-sides"[^>]*>\n?','',s)
def emb(m):
    b=base64.b64encode(open('img/'+m.group(1),'rb').read()).decode()
    return f'src="data:image/webp;base64,{b}"'
s=re.sub(r'src="img/([\w-]+\.webp)"',emb,s)
title=re.search(r'<title>.*?</title>',s).group(0); s=s.replace(title,'',1)
head=f'''<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">{title}
<style>:root{{padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);color-scheme:light}}body{{margin:0;font:14px system-ui,sans-serif}}img{{max-width:100%}}[hidden]{{display:none!important}}</style>
</head><body>
'''
# standalone: full content readable even if scripts are blocked
s=re.sub(r'(<section id="[a-z]+"[^>]*?) hidden>',r'\1>',s)
head=head.replace('</style>\n</head>','html:not(.js) #bar,html:not(.js) #tts-btn{display:none!important}html:not(.js) main{padding-bottom:40px!important}</style>\n<script>document.documentElement.className="js"</script>\n</head>')
s=s.replace('<link rel="icon"','<link rel="icon"')
out=head+s+'\n</body></html>\n'
p='dist/OUT_HX-STOMP_まるわかり辞典.html'
open(p,'w',encoding='utf8').write(out)
print(os.path.getsize(p)//1024,'KB','remaining img/ refs',len(re.findall(r'"img/',out)),'external css/js',re.findall(r'<(?:script|link)[^>]+(?:src|href)="http[^"]+',out)[:3])
