import re,os
from PIL import Image
R='/home/claude/web-app-out46/hx-stomp'
os.makedirs(R,exist_ok=True)
s=open('dist/OUT_HX-STOMP_まるわかり辞典.html',encoding='utf8').read()
o=Image.open('logo-clean.png').convert('RGBA')
for name,sz in [('icon-192.png',192),('icon-512.png',512),('apple-touch-icon.png',180)]:
    # square white ground with the round logo, slightly inset for home-screen masks
    bg=Image.new('RGB',(sz,sz),(255,255,255)); pad=int(sz*.04); t=o.resize((sz-2*pad,sz-2*pad),Image.LANCZOS); bg.paste(t,(pad,pad),t); bg.save(f'{R}/{name}',optimize=True)
open(f'{R}/manifest.webmanifest','w',encoding='utf8').write('''{
  "name": "OUT HX-STOMP まるわかり辞典",
  "short_name": "HX辞典",
  "start_url": "./",
  "scope": "./",
  "display": "standalone",
  "background_color": "#16191d",
  "theme_color": "#16191d",
  "lang": "ja",
  "icons": [
    {"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
    {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"}
  ]
}
''')
open(f'{R}/sw.js','w',encoding='utf8').write('''// OUT HX-STOMP まるわかり辞典: オフライン対応。ネット優先で更新を届け、圏外や遅い回線ではキャッシュを使う。
const CACHE = 'hx-stomp-v1';
const CORE = ['./', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png'];
self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('hx-stomp-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return;
  const key = e.request.mode === 'navigate' ? './' : e.request;
  e.respondWith(caches.open(CACHE).then(c => {
    const net = fetch(e.request, { cache: 'no-cache' }).then(r => { if (r && r.ok) c.put(key, r.clone()); return r; });
    const slow = new Promise(res => setTimeout(() => c.match(key).then(m => { if (m) res(m); }), 3000));
    return Promise.race([net.catch(() => c.match(key).then(m => m || Promise.reject(new Error('offline')))), slow]);
  }));
});
''')
tags='<link rel="manifest" href="manifest.webmanifest">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-title" content="HX辞典">\n<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n<meta name="theme-color" content="#16191d">\n'
s=s.replace('</head>',tags+'</head>',1)
s=re.sub(r'<link rel="apple-touch-icon" href="data:[^"]+">','<link rel="apple-touch-icon" href="apple-touch-icon.png">',s)
s=s.replace('</body></html>','<script>if ("serviceWorker" in navigator) { navigator.serviceWorker.register("sw.js", { scope: "./" }).catch(function () {}); }</script>\n</body></html>')
open(f'{R}/index.html','w',encoding='utf8').write(s)
print(os.path.getsize(f'{R}/index.html')//1024,'KB')
