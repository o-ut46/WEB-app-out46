OUT HX-STOMP まるわかり辞典 ソース
- hx-guide.html : 原本（画像は img/ を参照）
- python3 dist.py : 単体オフライン版 dist/OUT_HX-STOMP_まるわかり辞典.html（画像埋め込み）
- python3 pwa.py  : ホーム画面アプリ版を /home/claude/web-app-out46/hx-stomp/ へ書き出し
- crops.json/crops.py/sizes.json : マニュアル図の切り抜き定義と寸法
- models.json : HX Edit 3.15ガイドp.58-67のモデル表 / official.txt : 公式3.80一覧からの追加分
- logo-clean.png : O-UTロゴ（アイコン生成元）
編集後: dist.py → pwa.py → web-app-out46でcommit/push
